<?php


$string["interactions"] = 'Interactions';
$string["chooseinteractions"] = 'Choose which interactions you want to see';